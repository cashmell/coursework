<?php

$server = "localhost";
$eventname = "root";
$location = "";
$database = "webdev_coursework";

$conna = mysqli_connect($server, $eventname, $location, $database);

if(!$conna) {
    die("<script>alert('Connection Failed.')</script>");
}
?>