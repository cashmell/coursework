<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: finally.php");
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reservation | Booking</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="style4.css">

</head>
<body>
 <header class="header">
     <div class="container">
         <nav class="nav">
             <a href="index.php" class="logo">
                 <img src="./images/logo.png" alt="" class="logo-image">
             </a>
             <div class="hamburger-menu">
                 <i class="fas fa-bars open-state"></i>
                 <i class="fas fa-times close-state"></i>
             </div> 
             <ul class="nav-list">
             <li class="nav-item">
                    <a href="finally.php" class="nav-link"><?php echo "Welcome " . $_SESSION['username'] ?></a>
                </li>
                <li class="nav-item">
                    <a href="ua.php" class="nav-link">Home</a>
                </li>
                <li class="nav-item">
                    <a href="final30.php" class="nav-link">Rooms</a>
                </li>
                <li class="nav-item">
                    <a href="final20.php" class="nav-link">Bookings</a>
                </li>
                <li class="nav-item">
                    <a href="logout.php" class="nav-link">Logout</a>
                </li>
             </ul>
         </nav>
     </div>
 </header>

 <?php 
include 'configer.php';

error_reporting(0);

session_start();

if (isset($_POST['submit'])) {
	$eventname = $_POST['eventname'];
	$location = $_POST['location'];
    $amount = $_POST['amount'];
    $email = $_POST['email'];


	
		$sql = "SELECT * FROM createreserve WHERE email='$email'";
		$result = mysqli_query($conna, $sql);
		if (!$result->num_rows > 0) {
			$sql = "INSERT INTO users (eventname, location, amount)
					VALUES ('$eventname', '$location', '$amount')";
			$result = mysqli_query($conna, $sql);
			if ($result) {
				echo "<script>alert('Event created successfully.')</script>";
				$eventname = "";
				$location = "";
                $amount = "";  
                $email = ""; 
			}
	} else {
		echo "<script>alert('Event already created.')</script>";
	}
}
?>
        <form action="" method="POST" id="register" class="input-groupy">
            <input type="text" class="input-field" placeholder="eventname" name="eventname" value="<?php echo $eventname; ?>" required>
            <input type="text" class="input-field" placeholder="Location" name="location" value="<?php echo $location; ?>" required>
            <input type="text" class="input-field" placeholder="Amount" name="amount" value="<?php echo $amount; ?>" required>
            <input type="email" class="input-field" placeholder="Email Id" name="email" value="<?php echo $email; ?>" required>
            <button type="submit" class="submit-btn" name="submit">Create</button>
        </form>
 <script src="main.js"></script>
</body>
</html>