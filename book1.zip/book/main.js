//Selectors
let header = document.querySelector('.header');
let hamburgerMenu = document.querySelector('.hamburger-menu');

window.addEventListener('scroll', function() {
    let windowPostion = window.scrollY > 0;
    header.classList.toggle('active', window.scrollY > 0)/*you can use windowPosition as well*/
}

)

hamburgerMenu.addEventListener('click', function () {
    header.classList.toggle('menu-open');
})


var x = document.getElementById("login");
        var y = document.getElementById("register");
        var z = document.getElementById("btn");

        function register(){
            x.style.left = "-400px";
            y.style.left = "50px";
            z.style.left = "110px";

}

        function login(){
            x.style.left = "50px";
            y.style.left = "450px";
            z.style.left = "0px";
        }  