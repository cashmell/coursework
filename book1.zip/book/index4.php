<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Log In | Sign Up</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="style4.css">

</head>
<body>
    <header class="header">
        <div class="container">
            <nav class="nav">
                <a href="index.php" class="logo">
                    <img src="./images/logo.png" alt="" class="logo-image">
                </a>
                <div class="hamburger-menu">
                    <i class="fas fa-bars open-state"></i>
                    <i class="fas fa-times close-state"></i>
                </div> 
                <ul class="nav-list">
                   <li class="nav-item">
                       <a href="index.php" class="nav-link">Home</a>
                   </li>
                   <li class="nav-item">
                       <a href="index2.php" class="nav-link">Rooms</a>
                   </li>
                   <li class="nav-item">
                       <a href="index3.php" class="nav-link">Bookings</a>
                   </li>
                   <li class="nav-item">
                       <a href="index4.php" class="nav-link">Log In | Sign Up</a>
                   </li>
                </ul>
            </nav>
        </div>
    </header>
    <div class="heron">
        <div class="form-box">
           <div class="button-box">
               <div id="btn"></div>
                <button type="button" class="toggle-btn" onclick="login()">Log In</button>
                <button type="button" class="toggle-btn" onclick="register()">Sign Up</button>
           </div>
           <div class="social-icons">
               <a href="https://www.facebook.com"> <img src="./images/fbb.jfif"></a>
               <a href="https://www.pinterest.com"><img src="./images/pint.png"></a>
               <a href="https://www.tripadvisor.com"><img src="./images/twiii.png"></a>
               <a href="https://www.instagram.com"><img src="./images/inst.png"></a>
               <a href="https://twitter.com"><img src="./images/owl.png"></a>
        </div> 


<?php 
include 'config.php';

error_reporting(0);

session_start();

if (isset($_SESSION['username'])) {
    header("Location: ua.php");
}

if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$password = md5($_POST['password']);

	$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['username'] = $row['username'];
		header("Location: ua.php");
	}
}

if (isset($_POST['submit'])) {
	$use = $_POST['username'];
	$passw = md5($_POST['password']);

    if($use=="admin" && $passw=='nopass'){
        echo "Welcome Admin";
    }
}
?>
        <form action="" method="POST" id="login" class="input-groupy">
            <input type="text" class="input-field" placeholder="UserName" name="username" value="<?php echo $username ?>" required>
            <input type="password" class="input-field" placeholder="Enter Password" name="password" value="<?php echo $_POST['password'] ?>" required>
            <input type="checkbox" class="check-box"><span>Remember Password</span>
            <button type="submit" class="submit-btn" name="submit">Log In</button>
            </form>



<?php 
include 'config.php';

error_reporting(0);

session_start();

if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$cpassword = md5($_POST['cpassword']);

	if ($password == $cpassword) {
		$sql = "SELECT * FROM users WHERE email='$email'";
		$result = mysqli_query($conn, $sql);
		if (!$result->num_rows > 0) {
			$sql = "INSERT INTO users (username, email, password)
					VALUES ('$username', '$email', '$password')";
			$result = mysqli_query($conn, $sql);
			if ($result) {
				echo "<script>alert('Wow! User Registration Completed.')</script>";
				$username = "";
				$email = "";
                $_POST['password'] = "";
				$_POST['cpassword'] = "";
			}
		} else {
			echo "<script>alert('Woops! Email Already Exists.')</script>";
		}
		
	} else {
		echo "<script>alert('Please check you email or password.')</script>";
	}
}
?>
        <form action="" method="POST" id="register" class="input-groupy">
            <input type="text" class="input-field" placeholder="UserName" name="username" value="<?php echo $username; ?>" required>
            <input type="email" class="input-field" placeholder="Email Id" name="email" value="<?php echo $email; ?>" required>
            <input type="password" class="password" placeholder="Enter Password" name="password" value="<?php echo $_POST['password']; ?>" required>
            <input type="password" class="confirmpassword" placeholder="Confirm Password" name="cpassword" value="<?php echo $_POST['cpassword']; ?>" required>
            <input type="checkbox" class="check-box" required><span> I agree to the terms and conditions</span>
            <button type="submit" class="submit-btn" name="submit">Sign Up</button>
        </form>
        </div>  
    </div>
    <script src="main.js"></script>
</body>
</html>
