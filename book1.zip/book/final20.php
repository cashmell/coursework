<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index4.php");
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Millennium Booking</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="style3.css">

</head>
<body>
 <header class="header">
     <div class="container">
         <nav class="nav">
             <a href="index.php" class="logo">
                 <img src="./images/logo.png" alt="" class="logo-image">
             </a>
             <div class="hamburger-menu">
                 <i class="fas fa-bars open-state"></i>
                 <i class="fas fa-times close-state"></i>
             </div> 
             <ul class="nav-list">
             <li class="nav-item">
                    <a href="finally.php" class="nav-link"><?php echo "Welcome " . $_SESSION['username'] ?></a>
                </li>
                <li class="nav-item">
                    <a href="ua.php" class="nav-link">Home</a>
                </li>
                <li class="nav-item">
                    <a href="final30.php" class="nav-link">Rooms</a>
                </li>
                <li class="nav-item">
                    <a href="final20.php" class="nav-link">Bookings</a>
                </li>
                <li class="nav-item">
                    <a href="logout.php" class="nav-link">Logout</a>
                </li>
             </ul>
         </nav>
     </div>
 </header>

    <section class="booking">
        <div class="container">
            <form action="" class="form book-form">
                <div class="input-group">
                    <label for="destination" class="input-label">Room / Location</label>
                    <input type="text" class="input" id="destination">
                </div>
                <div class="input-group">
                   <label for="check-in" class="input-label">Check-In Date</label>
                   <input type="date" class="input" id="check-in">
               </div>
               <div class="input-group">
                   <label for="check-out" class="input-label">Check-Out Date</label>
                   <input type="date" class="input" id="check-out">
               </div>
               <div class="input-group">
                   <label for="adults" class="input-label">Adults</label>
                   <select class="options" id="adults">
                       <option value="0">0</option>
                       <option value="0">1</option>
                       <option value="0">2</option>
                       <option value="0">3</option>
                       <option value="0">4</option>
                       <option value="0">5</option>
                       <option value="0">6</option>
                       <option value="0">7</option>
                       <option value="0">8</option>
                       <option value="0">9</option>
                       <option value="0">10</option>
                       <option value="0">11</option>
                       <option value="0">12</option>
                       <option value="0">13</option>
                   </select>
               </div>
               <div class="input-group">
                   <label for="children" class="input-label">Children</label>
                   <select class="options" id="children">
                       <option value="0">0</option>
                       <option value="0">1</option>
                       <option value="0">2</option>
                       <option value="0">3</option>
                       <option value="0">4</option>
                       <option value="0">5</option>
                       <option value="0">6</option>
                       <option value="0">7</option>
                       <option value="0">8</option>
                   </select>
               </div>
               <button type="submit" class="btn form-btn btn-purple">Book
                   <span class="dots"><i class="fas fa-ellipsis-h"></i></span>
               </button>
            </form>
        </div>
    </section>


        <div class="contender">
            <div class="calender">
                <div class="month">
                    <i class="fas fa-angle-left prev"></i>
                    <div class="date">
                    <h1></h1>
                    <p></p>
                    </div>
                    <i class="fas fa-angle-right next"></i>
                </div>
                <div class="weekdays">
                    <div>Sun</div>
                    <div>Mon</div>
                    <div>Tue</div>
                    <div>Wed</div>
                    <div>Thu</div>
                    <div>Fri</div>
                    <div>Sat</div>
                </div>
                <div class="days">
                    <div class="prev-date">28</div>
                    <div class="prev-date">29</div>
                    <div class="prev-date">30</div>
                    <div class="prev-date">31</div>
                    <div>1</div>
                    <div>2</div>
                    <div>3</div>
                    <div>4</div>
                    <div>5</div>
                    <div>6</div>
                    <div>7</div>
                    <div>8</div>
                    <div>9</div>
                    <div>10</div>
                    <div>11</div>
                    <div>12</div>
                    <div>13</div>
                    <div>14</div>
                    <div>15</div>
                    <div>16</div>
                    <div>17</div>
                    <div>18</div>
                    <div>19</div>
                    <div>20</div>
                    <div>21</div>
                    <div>22</div>
                    <div>23</div>
                    <div>24</div>
                    <div>25</div>
                    <div>26</div>
                    <div>27</div>
                    <div>28</div>
                    <div class="today">29</div>
                    <div>30</div>
                    <div>31</div>
                    <div class="next-date">1</div>
                    <div class="next-date">2</div>
                    <div class="next-date">3</div>
                    <div class="next-date">4</div>
                    <div class="next-date">5</div>
                    <div class="next-date">6</div>
                    <div class="next-date">7</div>
                    
                </div>
            </div>
        </div>
    <script src="main.js"></script>
    <script src="jsmain.js"></script>
    
</body>
</html>