<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Millennium Booking</title>
    <!--Font awesome CDN-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="style1.css">

</head>
<body>
 <header class="header">
     <div class="container">
         <nav class="nav">
             <a href="index.php" class="logo">
                 <img src="./images/logo.png" alt="" class="logo-image">
             </a>
             <div class="hamburger-menu">
                 <i class="fas fa-bars open-state"></i>
                 <i class="fas fa-times close-state"></i>
             </div> 
             <ul class="nav-list">
                <li class="nav-item">
                    <a href="index.php" class="nav-link">Home</a>
                </li>
                <li class="nav-item">
                    <a href="index2.php" class="nav-link">Rooms</a>
                </li>
                <li class="nav-item">
                    <a href="index3.php" class="nav-link">Bookings</a>
                </li>
                <li class="nav-item">
                    <a href="index4.php" class="nav-link">Log In | Sign Up</a>
                </li>
             </ul>
         </nav>
     </div>
 </header>

 <main class="main">
     <div class="hero">
         <div class="container">
            <div class="main-heading">
                <h1 class="title">Discover</h1>
                <h2 class="subtitle">Luxury Hotels</h2>
            </div>
            <a href="index2.php" class="btn btn-gradient">Explore Now!
                <span class="dots"><i class="fas fa-ellipsis-h"></i></span>
            </a>
         </div>
     </div>

     
     <section class="hotels">
         <div class="container">
             <h5 class="section-head">
                 <span class="heading">Explore</span>
                 <span class="sub-heading">Our Beautiful Hotels</span>
             </h5>
             <div class="grid">
                 <div class="grid-item featured-hotels">
                     <img src="./images/hotel_astro_resort.jpg" alt="" class="hotel-image">
                     <h5 class="hotel-name">Astro Hotel</h5>
                     <span class="hotel-price">From $200/Night</span>
                     <div class="hotel-rating">
                         <i class="fas fa-star rating"></i>
                         <i class="fas fa-star rating"></i>
                         <i class="fas fa-star rating"></i>
                         <i class="fas fa-star rating"></i>
                         <i class="fas fa-star-half rating"></i>
                     </div>
                     <a href="index3.php" class="btn btn-gradient">Book Now!
                        <span class="dots"><i class="fas fa-ellipsis-h"></i></span>
                     </a>
                 </div>

                 <div class="grid-item featured-hotels">
                    <img src="./images/hotel_the_enchanted_garden.jpg" alt="" class="hotel-image">
                    <h5 class="hotel-name">Enchanted Garden</h5>
                    <span class="hotel-price">From $300/Night</span>
                    <div class="hotel-rating">
                        <i class="fas fa-star rating"></i>
                        <i class="fas fa-star rating"></i>
                        <i class="fas fa-star rating"></i>
                        <i class="fas fa-star rating"></i>
                        <i class="fas fa-star rating"></i>
                    </div>
                    <a href="index3.php" class="btn btn-gradient">Book Now!
                       <span class="dots"><i class="fas fa-ellipsis-h"></i></span>
                    </a>
                </div>

                <div class="grid-item featured-hotels">
                    <img src="./images/hotel_the_paradise.jpg" alt="" class="hotel-image">
                    <h5 class="hotel-name">The Paradise</h5>
                    <span class="hotel-price">From $280/Night</span>
                    <div class="hotel-rating">
                        <i class="fas fa-star rating"></i>
                        <i class="fas fa-star rating"></i>
                        <i class="fas fa-star rating"></i>
                        <i class="fas fa-star rating"></i>
                        <i class="fas fa-star-half rating"></i>
                    </div>
                    <a href="index3.php" class="btn btn-gradient">Book Now!
                       <span class="dots"><i class="fas fa-ellipsis-h"></i></span>
                    </a>
                </div>
             </div>
         </div>
     </section>
     <section class="offer">
         <div class="container">
             <div class="offer-content">
                 <div class="discount">
                     40% off
                 </div>
                 <h5 class="hotel-name">The Paradise</h5>
                 <div class="hotel-rating">
                    <i class="fas fa-star rating"></i>
                    <i class="fas fa-star rating"></i>
                    <i class="fas fa-star rating"></i>
                    <i class="fas fa-star rating"></i>
                    <i class="fas fa-star-half rating"></i>
                 </div>
                    <p class="paragraph">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores possimus accusamus reiciendis temporibus cum rerum? 
                        Et, sequi, officia mollitia fugiat distinctio maxime facilis facere velit omnis nemo quo odit non.
                    </p>
                    <a href="index2.php" class="btn btn-gradient">Redeem Offer
                        <span class="dots"><i class="fas fa-ellipsis-h"></i></span>
                     </a>
                 </div>
             </div>
         </div>
     </section>

     <section class="Contact">
         <div class="container">
             <h5 class="section-head">
                 <span class="heading">Contact</span>
                 <span class="sub-heading">Get In Touch With Us</span>
             </h5>
             <div class="contact-content">
                 <div class="traveler-wrap">
                     <img src="./images/traveler.png" alt="">
                 </div>
                 <form action="" class="form contact-form">
                     <div class="input-group-wrap">
                         <div class="input-group">
                             <input type="text" class="input" placeholder="Name" required>
                             <span class="bar"></span>
                         </div>

                         <div class="input-group">
                            <input type="email" class="input" placeholder="E-mail" required>
                            <span class="bar"></span>
                        </div>
                    </div>
                        <div class="input-group">
                            <input type="text" class="input" placeholder="Subject" required>
                            <span class="bar"></span>
                        </div>

                        <div class="input-group">
                            <textarea class="input" cols="30" rows="8" placeholder="E-mail" required></textarea>
                            <span class="bar"></span>
                        </div>
                        <button type="submit" class="btn form-btn btn-purple">Send Message
                        <span class="dots"><i class="fas fa-ellipsis-h"></i></span>
                    </button>
                 </form>
             </div>
         </div>
     </section>
 </main>

 <footer class="footer">
     <div class="container">
         <div class="footer-content">
             <div class="footer-content-brand">
                 <a href="index.php" class="logo">
                     <img class="logo-image" src="./images/logo.png" alt="">
                 </a>
                 <div class="paragraph">
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                 </div>
             </div>
             <div class="social-media-wrap">
                 <h4 class="footer-heading">Follow Us</h4>
                 <div class="social-media">
                     <a href="https://twitter.com" class="sm-link"><i class="fab fa-twitter"></i></a>
                     <a href="https://www.facebook.com" class="sm-link"><i class="fab fa-facebook-square"></i></a>
                     <a href="https://www.instagram.com" class="sm-link"><i class="fab fa-instagram"></i></a>
                     <a href="https://www.pinterest.com" class="sm-link"><i class="fab fa-pinterest"></i></a>
                     <a href="https://www.tripadvisor.com" class="sm-link"><i class="fab fa-tripadvisor"></i></a>
                 </div>
             </div>
         </div>
     </div>
 </footer>
    <script src="main.js"></script>
</body>
</html>