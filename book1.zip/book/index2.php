<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Rooms</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <nav class="nav">
                <a href="index.php" class="logo">
                    <img src="./images/logo.png" alt="" class="logo-image">
                </a>
                <div class="hamburger-menu">
                    <i class="fas fa-bars open-state"></i>
                    <i class="fas fa-times close-state"></i>
                </div> 
                <ul class="nav-list">
                   <li class="nav-item">
                       <a href="index.php" class="nav-link">Home</a>
                   </li>
                   <li class="nav-item">
                       <a href="index2.php" class="nav-link">Rooms</a>
                   </li>
                   <li class="nav-item">
                       <a href="index3.php" class="nav-link">Bookings</a>
                   </li>
                   <li class="nav-item">
                       <a href="index4.php" class="nav-link">Log In | Sing Up</a>
                   </li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="rooms">
        <div class="container">
            <h5 class="section-head">
               <span class="heading">Luxurious</span>
               <span class="sub-heading">Affordable rooms</span>
            </h5>
            <div class="grid rooms-grid">
                <div class="grid-item-featured-rooms">
                    <div class="image-wrap">
                       <img class="room-image" src="./images/room_1.jpg" alt="">
                       <h5 class="room-name">Astro Hotel</h5>
                   </div>
                   <div class="room-info-wrap">
                       <span class="room-price">$200 <span class="per-night">Per</span></span>
                       <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                           Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                           Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                           <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
                   </div>
                </div>

                <div class="grid-item-featured-rooms">
                   <div class="image-wrap">
                      <img class="room-image" src="./images/room_2.jpg" alt="">
                      <h5 class="room-name">The Paradise</h5>
                  </div>
                  <div class="room-info-wrap">
                      <span class="room-price">$200 <span class="per-night">Per</span></span>
                      <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                          Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                          Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                          <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
                  </div>
               </div>

               <div class="grid-item-featured-rooms">
                   <div class="image-wrap">
                      <img class="room-image" src="./images/room17.jfif" alt="">
                      <h5 class="room-name">The Wing</h5>
                  </div>
                  <div class="room-info-wrap">
                      <span class="room-price">$200 <span class="per-night">Per</span></span>
                      <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                          Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                          Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                          <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
                  </div>
               </div>

               <div class="grid-item-featured-rooms">
                   <div class="image-wrap">
                      <img class="room-image" src="./images/room_9.jpg" alt="">
                      <h5 class="room-name">Enchanted Garden</h5>
                  </div>
                  <div class="room-info-wrap">
                      <span class="room-price">$200 <span class="per-night">Per</span></span>
                      <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                          Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                          Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                          <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
                  </div>
               </div>

               <div class="grid-item-featured-rooms">
                <div class="image-wrap">
                   <img class="room-image" src="./images/room_4.jpg" alt="">
                   <h5 class="room-name">Greece's Paradise</h5>
               </div>
               <div class="room-info-wrap">
                   <span class="room-price">$200 <span class="per-night">Per</span></span>
                   <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                       Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                       Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                       <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
               </div>
            </div>

            <div class="grid-item-featured-rooms">
                <div class="image-wrap">
                   <img class="room-image" src="./images/room_7.jpg" alt="">
                   <h5 class="room-name">Chillidad's</h5>
               </div>
               <div class="room-info-wrap">
                   <span class="room-price">$200 <span class="per-night">Per</span></span>
                   <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                       Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                       Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                       <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
               </div>
            </div>

            <div class="grid-item-featured-rooms">
                <div class="image-wrap">
                   <img class="room-image" src="./images/room_10.jpg" alt="">
                   <h5 class="room-name">Lares</h5>
               </div>
               <div class="room-info-wrap">
                   <span class="room-price">$200 <span class="per-night">Per</span></span>
                   <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                       Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                       Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                       <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
               </div>
            </div>

            <div class="grid-item-featured-rooms">
                <div class="image-wrap">
                   <img class="room-image" src="./images/room_7.jpg" alt="">
                   <h5 class="room-name">Jamiekun</h5>
               </div>
               <div class="room-info-wrap">
                   <span class="room-price">$200 <span class="per-night">Per</span></span>
                   <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                       Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                       Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                       <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
               </div>
            </div>

            <div class="grid-item-featured-rooms">
                <div class="image-wrap">
                   <img class="room-image" src="./images/room15.jfif" alt="">
                   <h5 class="room-name">Ioshikami</h5>
               </div>
               <div class="room-info-wrap">
                   <span class="room-price">$200 <span class="per-night">Per</span></span>
                   <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                       Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                       Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                       <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
               </div>
            </div>

            <div class="grid-item-featured-rooms">
                <div class="image-wrap">
                   <img class="room-image" src="./images/room_8.jpg" alt="">
                   <h5 class="room-name">Piece</h5>
               </div>
               <div class="room-info-wrap">
                   <span class="room-price">$200 <span class="per-night">Per</span></span>
                   <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                       Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                       Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                       <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
               </div>
            </div>

            <div class="grid-item-featured-rooms">
                <div class="image-wrap">
                   <img class="room-image" src="./images/room11.jpg" alt="">
                   <h5 class="room-name">Yami Board Room</h5>
               </div>
               <div class="room-info-wrap">
                   <span class="room-price">$200 <span class="per-night">Per</span></span>
                   <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                       Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                       Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                       <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
               </div>
            </div>

            <div class="grid-item-featured-rooms">
                <div class="image-wrap">
                   <img class="room-image" src="./images/room13.jfif" alt="">
                   <h5 class="room-name">Pagana Board Room</h5>
               </div>
               <div class="room-info-wrap">
                   <span class="room-price">$200 <span class="per-night">Per</span></span>
                   <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                       Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                       Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                       <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
               </div>
            </div>

            <div class="grid-item-featured-rooms">
                <div class="image-wrap">
                   <img class="room-image" src="./images/room12.jpg" alt="">
                   <h5 class="room-name">Serpien Board Room</h5>
               </div>
               <div class="room-info-wrap">
                   <span class="room-price">$200 <span class="per-night">Per</span></span>
                   <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                       Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                       Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                       <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
               </div>
            </div>

            <div class="grid-item-featured-rooms">
                <div class="image-wrap">
                   <img class="room-image" src="./images/room14.jfif" alt="">
                   <h5 class="room-name">Packari</h5>
               </div>
               <div class="room-info-wrap">
                   <span class="room-price">$200 <span class="per-night">Per</span></span>
                   <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                       Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                       Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                       <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
               </div>
            </div>

            <div class="grid-item-featured-rooms">
                <div class="image-wrap">
                   <img class="room-image" src="./images/room16.jpg" alt="">
                   <h5 class="room-name">Gandom</h5>
               </div>
               <div class="room-info-wrap">
                   <span class="room-price">$200 <span class="per-night">Per</span></span>
                   <p class="paragraph">Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                       Reprehenderit odio incidunt placeat earum dolorum blanditiis dignissimos reiciendis quas ipsam. 
                       Alias molestias sequi dolor fuga dolorum possimus quisquam explicabo optio! Veniam!</p>
                       <a href="index3.php" class="btn-rooms-btn">Book Now! &rarr;</a>
               </div>
            </div>

            </div>
        </div>
    </section>
    <script src="main.js"></script>  
</body>
</html>